<?php session_start();

if (
    // isset($_SESSION['user']) &&
    empty($_SESSION['user']) == false
) {
    // người dùng đã đăng nhập -> đẩy về trang quản trị
    $login = "Đăng xuất";
    $link = "/trongtdph17510_ass/SourceFile/tai-khoan/dang-xuat.php";
    $name =  '<i class="fas fa-user-circle" style="color: #fff; margin-right: 8px; font-size: 24px;"></i>' . $_SESSION['user']['ho_ten'];
    if ($_SESSION['user']['vai_tro'] == 0) {
        $link_admin = "/trongtdph17510_ass/SourceFile/admin/hang-hoa/index.php";
        $name_admin = "Quản lý";
    } else {
        $link_admin = "";
        $name_admin = "";
    }
} else {
    // $logout = "đăng xuất";
    $login = "Đăng nhập";
    $link = "/trongtdph17510_ass/SourceFile/tai-khoan/";
    $name = "";
    $link_admin = "";
    $name_admin = "";
}

?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>Web design sample project</title>
    <!--jQuery-->
    <!-- <script src="/trongtdph17510_ass/SourceFile/content/js/jquery.m/in.js"></script> -->
    <!--Bootstrap-->
    <!-- <script src=""></script> -->
    <link href="/trongtdph17510_ass/SourceFile/content/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta2/css/all.min.css" integrity="sha512-YWzhKL2whUzgiheMoBFwW8CKV4qpHQAEuvilg9FAn5VJUDwKZZxkJNuGM4XkWuk94WCrrwslk8yWNGmY1EduTA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>

<body class="container">
    <!-- <h1>Bán hàng trực tuyến</h1>
    <hr> -->
    <nav class="navbar navbar-expand-sm bg-dark navbar-dark" style="padding-left: 16px; position: relative;">
        <a href="/trongtdph17510_ass/SourceFile/home?trang-chu"><img src="http://localhost/trongtdph17510_ass/SourceFile/content/img/logo.png" width="100px" style="background-color: #fff; margin-right: 16px;" alt=""></a>
        <a class="navbar-brand" href="/trongtdph17510_ass/SourceFile/home?trang-chu">Trang chủ</a> 
        <a class="navbar-brand" href="/trongtdph17510_ass/SourceFile/home?gioi-thieu">Giới thiệu</a> 
        <a class="navbar-brand" href="/trongtdph17510_ass/SourceFile/home?lien-he">Liên hệ</a> 
        <a class="navbar-brand" href="/trongtdph17510_ass/SourceFile/home?san-pham">Sản phẩm</a> 
        <a class="navbar-brand" href="<?= $link_admin ?>"><?= $name_admin ?></a> 
        <div style="float: right; position: absolute; right: 10px;">
            <a class="navbar-brand" href="/trongtdph17510_ass/SourceFile/tai-khoan?btn_account"><?php echo $name; ?></a>
            <a class="navbar-brand" href="<?= $link ?>"><?php echo $login; ?></a>
            <a class="navbar-brand" href="/trongtdph17510_ass/SourceFile/cart/cart.php"><i class="fas fa-shopping-cart" style="color: #fff;"></i></a>
        </div>
    </nav>

    <hr>
    <div style="min-height: 300px;">
        <?php
        require $VIEW_NAME;
        ?>
    </div>
    <div class="card" style="text-align: center; background-color: rgba( 0, 0, 0, 0.3);">
        <div class="card-body">
            <h5 class="card-title">Địa chỉ: Cầu Giấy - Hà Nội</h5>
            <p class="card-text">Hotline: 19001001</p>
            <p class="card-text">Gmail: trongtdph17510_ass@gmail.com</p>
        </div>

    </div>
</body>

</html>