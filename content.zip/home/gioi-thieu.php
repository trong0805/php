<!DOCTYPE html>
<html>
<style>
    .content {
        text-align: center;
    }

    .row {
        display: flex;
        align-items: center;
    }

    .heading {
        width: 50%;
        padding: 56px 0px;
    }

    .text {
        width: 50%;
        padding: 56px;
    }

    .heading>h1 {
        font-size: 156px;
        font-weight: bold;
        font-family: Arial, Helvetica, sans-serif;
    }
</style>

<body>
    <div class="content">
        <h2>GIỚI THIỆU</h2>
        <div class="row">
            <div class="heading">
                <h1>Xshop</h1>
            </div>
            <div class="text">
                <p>
                    Previous
                    Next
                    Với mong muốn mang đến cho khách hàng sự trải nghiệm tốt nhất khi mua sắm các sản phẩm thời trang, trong thời gian qua XSHOP không ngừng mở rộng các cửa hàng khắp Hà Nội
                    Năm 2019, mục tiêu của XSHOP sẽ tiếp tục mở thêm nhiều hệ thống cửa hàng nữa để đem đến cho khách hàng những sản phẩm thời trang phù hợp với nhu cầu, giá cả tốt nhất và dịch vụ hoàn hảo

                    Mời bạn xem một số hình ảnh sinh động tại cửa hàng XSHOP.</p>
            </div>
        </div>
        <div style="margin-bottom: 16px;">
            <div class="container">
                <div class="row">
                    <div class="col" style="padding: 0;">
                        <img class="img" width="100%" src="./../content/img/pageslap.jpg" alt="">
                    </div>
                    <div class="col" style="padding: 0;">
                        <img class="img" width="100%" src="./../content/img/pageslap1.jpg" alt="">
                    </div>
                </div>
                <div class="row">
                    <div class="col" style="padding: 0;">
                        <img class="img" width="100%" src="./../content/img/slide1.jpg" alt="">
                    </div>
                    <div class="col" style="padding: 0;">
                        <img class="img" width="100%" src="./../content/img/slide2.jpg" alt="">
                    </div>
                    <div class="col" style="padding: 0;">
                        <img class="img" width="100%" src="./../content/img/slide3.jpg" alt="">
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>