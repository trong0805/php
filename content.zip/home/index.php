<?php
if (array_key_exists("gioi-thieu", $_REQUEST)) {
    $VIEW_NAME = "./gioi-thieu.php";
} else if (array_key_exists("lien-he", $_REQUEST)) {
    $VIEW_NAME = "./lien-he.php";
} else if (array_key_exists("san-pham", $_REQUEST)) {
    $VIEW_NAME = "./san-pham.php";
} else {
    $VIEW_NAME = "./trang-chu.php";
}
require '../layout.php';
