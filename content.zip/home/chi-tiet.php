    <?php
    session_start();
    require_once './../admin/db/dbhang-hoa.php';
    require_once './../admin/db/dbbinh-luan.php';

    $id = $_GET['ma_hh'];
    $data = getid($id);
    $data_bl = getall_bl_id($id);

    // echo $_SESSION['user']['ma_kh'];
    ?>

    <!DOCTYPE html>
    <html>
    <!-- CSS only -->
    <!-- JavaScript Bundle with Popper -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta2/css/all.min.css" integrity="sha512-YWzhKL2whUzgiheMoBFwW8CKV4qpHQAEuvilg9FAn5VJUDwKZZxkJNuGM4XkWuk94WCrrwslk8yWNGmY1EduTA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
    <link href="./chi-tiet.css" type="text/css" rel="stylesheet" />
    <style>
        .comment_edit {
            position: fixed;
            top: 40%;
            left: 20%;
            right: 20%;
            /* bottom: 50%; */
            display: none;
            z-index: 10;
            padding: 60px;
            border: 1px solid black;
            background-color: bisque;
        }

        .overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            display: none;
            background: rgba(0, 0, 0, 0.35);
        }

        .update:checked~.comment_edit {
            display: block;
        }

        .update:checked~.overlay {
            display: block;
        }
    </style>

    <body>
        <div class="container">
            <?php require_once './../header.php'; ?>
            <h2 class="alert alert-danger">Chi tiết sản phẩm</h2>
            <div class="thong_tin">
                <img class="img" src="./../content/img/<?= $data['hinh'] ?>" alt="">
                <div class="content">
                    <h2 class="card-title" style="min-height: 50px;"><?= $data['ten_hh'] ?></h2>
                    <p class="card-text" style="font-size: 24px;">Giá: <span style="color: red; "><?= $data['don_gia'] ?>$</span> </p>
                    <p class="card-text">
                    <h4>Số lượng</h4>
                    </p>
                    <form method="POST" action="/trongtdph17510_ass/SourceFile/cart/cart.php" enctype="multipart/form-data">
                        <input type="hidden" value="<?= $data['ten_hh'] ?>" name="ten_hh" />
                        <input type="hidden" value="<?= $data['don_gia'] ?>" name="don_gia" />
                        <input type="hidden" value="<?= $data['hinh'] ?>" name="hinh" />
                        <input type="hidden" value="<?= $data['ma_hh'] ?>" name="ma_hh" />
                        <input class="btn btn-primary" style="padding: 5px 15px;" onclick="var result = document.getElementById('quantity'); var qty = result.value; if( !isNaN(qty) &amp; qty > 1 ) result.value--;return false;" type='button' value='-' />
                        <input type="text" style="width: 100px; padding-bottom: 5px; text-align: center;" id="quantity" name="so_luong" value="0" />
                        <input class="btn btn-primary" style="padding: 5px 13px;" onclick="var result = document.getElementById('quantity'); var qty = result.value; if( !isNaN(qty)) result.value++;return false;" type='button' value='+' /> <br> <br>
                        <input name="addcart" id="" class="btn btn-primary" type="submit" value="Mua sản phẩm">
                    </form>
                </div>
            </div>
            <div class="mo_ta">
                <h2 class="heading card-title">Mô tả</h2>
                <p class="text"><?= $data['mo_ta'] ?></p>
            </div>
            <div>
                <h2 class="heading card-title">Bình luận</h2>
                <table class="table" style="position: relative;">
                    <thead>
                        <tr>
                            <th></th>
                            <th>Tên</th>
                            <th>ngày bình luận</th>
                            <th>Nội dung</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($data_bl as $bl) {
                            extract($bl) ?>
                            <tr>
                                <td><img src="./../content/img/<?= $hinh ?>" width="40px" alt=""></td>
                                <td><?= $ho_ten ?></td>
                                <td><?= $ngay_bl ?></td>
                                <td><?= $noi_dung ?></td>
                                <td>
                                    <?php if (isset(($_SESSION['user']))) {
                                        if ($_SESSION['user']['ma_kh'] == $ma_kh) { ?>
                                            <!-- <lable for="ok">Sửa</lable> -->
                                            <label for="ok" class="btn btn-primary"> Sửa</label>
                                            
                                        <?php } ?>
                                        <?php if ($_SESSION['user']['ma_kh'] == $ma_kh || $_SESSION['user']['vai_tro'] == 0) { ?>
                                            <a class="btn btn-primary" href="./../admin/binh-luan/delete.php?ma_bl=<?= $ma_bl ?>" onclick="return confirm('Bạn muốn xóa bình luận này?');">Xóa</a>
                                        <?php  } else {
                                        } ?>
                                    <?php } ?>
                                </td>
                            </tr>
                            <input type="checkbox" id="ok" name="" class="update" hidden>
                                            <!-- //chỉnh sửa bình luận -->
                                            <div class="comment_edit">
                                                <form action="/trongtdph17510_ass/SourceFile/admin/binh-luan/update.php?ma_hh=<?= $data['ma_hh']; ?>" method="post" class="input-group flex-nowrap">
                                                    <!-- <div > -->
                                                    <span class="input-group-text" id="addon-wrapping">Nội dung</span>
                                                    <input class="form-control" type="text" hidden name="ma_bl" placeholder="Mã bình luận" value="<?= $ma_bl ?>">
                                                    <input class="form-control" type="text" hidden name="ma_hh" value="<?= $data['ma_hh'] ?>" placeholder="Mã hàng hóa">
                                                    <input class="form-control" type="text" hidden name="ma_kh" value="
                                                        <?php if (isset(($_SESSION['user']))) { ?>
                                                            <?= $_SESSION['user']['ma_kh'] ?>
                                                        <?php } ?>" placeholder="Mã khách hàng">
                                                    <input type="text" class="form-control" name="noi_dung" placeholder="Nhập nội dung bình luận mới" value="<?= $noi_dung ?>" aria-label="Username" aria-describedby="addon-wrapping">
                                                    <button class="btn btn-primary">Sửa</button>
                                                    <!-- </div> -->
                                                </form>
                                            </div>
                                            <label for="ok" class="overlay"></label>
                        <?php } ?>
                    </tbody>
                </table>
                <?php if (isset(($_SESSION['user']))) { ?>
                    <form method="post" action="/trongtdph17510_ass/SourceFile/admin/binh-luan/insert_bl.php?ma_hh=<?= $data['ma_hh']; ?>">
                        <input class="form-control" type="text" hidden name="ma_bl" placeholder="Mã bình luận">
                        <input class="form-control" type="text" name="noi_dung" placeholder="Nội dung bình luận" required><br>
                        <input class="form-control" type="text" hidden name="ma_hh" value="<?= $data['ma_hh'] ?>" placeholder="Mã hàng hóa">
                        <input class="form-control" type="text" hidden name="ma_kh" value="
                        <?php if (isset(($_SESSION['user']))) { ?>
                            <?= $_SESSION['user']['ma_kh'] ?>
                        <?php } ?>" placeholder="Mã khách hàng">
                        <input class="form-control" type="date" hidden name="ngay_bl" value="<?php echo date('Y-m-d') ?>" placeholder="Ngày bình luận">
                        <button class="btn btn-primary"> Bình luận</button>
                    </form>
                <?php } else { ?>
                    <center style="color: red;">Bạn cần đăng nhập để dùng chức năng bình luận!</center>
                    <center><a href="./../tai-khoan/?dang-nhap">Đăng nhập ngay?</a></center>
                <?php } ?>
            </div>
            <?php require_once './../footer.php'; ?>
        </div>
    </body>

    </html>