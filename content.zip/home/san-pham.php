<?php
require_once './../admin/db/dbhang-hoa.php';
$data1 = getall1();
$data = getall();
?>
<!DOCTYPE html>
<html>
<!-- CSS only -->
<!-- JavaScript Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous"></script>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
<link href="./san-pham.css" type="text/css" rel="stylesheet" />

<body>
    <div class="container">
        <div class="row">

            <div class="article">
                <div class="products">
                    <h2>Danh mục</h2>
                    <div class="grid_row">
                        <?php
                        foreach ($data as $ds) { ?>
                            <div class="g-col-4" style="margin-bottom: 10px;">
                                <div class="card" style="width: 18rem;">
                                    <a href="./../home/chi-tiet.php?ma_hh=<?= $ds['ma_hh'] ?>"><img src="./../content/img/<?= $ds['hinh'] ?>" class="card-img-top" alt="..."></a>
                                    <div class="card-body" style="text-align: center;">
                                        <h5 class="card-title" style="min-height: 50px;"><a href="./../home/chi-tiet.php?ma_hh=<?= $ds['ma_hh'] ?>"><?= $ds['ten_hh'] ?></a></h5>
                                        <p class="card-text">Giá: <span style="color: red;"><?= $ds['don_gia'] ?>$</span> </p>
                                        <!-- <a href="" class="btn btn-primary">BUY NOW</a> -->
                                        <form method="POST" action="/trongtdph17510_ass/SourceFile/cart/cart.php" enctype="multipart/form-data">
                                            <input type="hidden" value="<?= $ds['ten_hh'] ?>" name="ten_hh" />
                                            <input type="hidden" value="<?= $ds['don_gia'] ?>" name="don_gia" />
                                            <input type="hidden" value="<?= $ds['hinh'] ?>" name="hinh" />
                                            <input type="hidden" value="<?= $ds['ma_hh'] ?>" name="ma_hh" />
                                            <input type="hidden" name="so_luong" value="1" />
                                            <input name="addcart" id="" class="btn btn-primary" type="submit" value="Mua sản phẩm">
                                        </form>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>

                    </div>
                </div>
            </div>
            <div class="aside">

                <div class="aside-bottom">
                    <h4>Danh mục</h4>
                    <?php
                    foreach ($data1 as $datas) { ?>
                        <a href="./san-pham_loai.php?ma_loai=<?= $datas['ma_loai'] ?>" class="list-group-item  "><?= $datas['ten_loai'] ?></a>
                    <?php } ?>
                </div>
            </div>
        </div>
    </div>
</body>

</html>