<?php
require_once './../admin/db/dbhang-hoa.php';
$post = getall();
$data = get_product_4();
$new = get_product_new();
$post = random();

$post1 = random1();
?>
<!DOCTYPE html>
<html>
<!-- CSS only -->
<!-- JavaScript Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-/bQdataTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous"></script>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
<link href="./trang-chu.css" type="text/css" rel="stylesheet" />

<body>
    <div class="container">
        <div class="row">

            <div class="article">
                <div class="slide">
                    <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel">
                        <div class="carousel-indicators">
                            <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                            <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
                            <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
                        </div>
                        <div class="carousel-inner">
                            <div class="carousel-item active">
                                <img src="./../content/img/slide1.jpg" class="d-block w-100" alt="...">
                            </div>
                            <div class="carousel-item">
                                <img src="./../content/img/slide2.jpg" class="d-block w-100" alt="...">
                            </div>
                            <div class="carousel-item">
                                <img src="./../content/img/slide3.jpg" class="d-block w-100" alt="...">
                            </div>
                        </div>
                        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                            <span class="visually-hidden">Previous</span>
                        </button>
                        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                            <span class="visually-hidden">Next</span>
                        </button>
                    </div>
                </div>
                <div class="products">
                    <h3 class="heading-prd">Sản phẩm yêu thích</h3>
                    <div class="grid_row">
                        <?php for ($i = 0; $i < count($data); $i++) { ?>
                            <div class="g-col-4" style="margin-bottom: 10px;">
                                <div class="card" style="width: 18rem;">
                                    <a href="./../home/chi-tiet.php?ma_hh=<?= $data[$i]['ma_hh'] ?>"><img src="./../content/img/<?= $data[$i]['hinh']  ?>" class="card-img-top" alt="..."></a>
                                    <div class="card-body" style="text-align: center;">
                                        <h5 class="card-title" style="min-height: 50px;"><a href="./../home/chi-tiet.php?ma_hh=<?= $data[$i]['ma_hh'] ?>"><?= $data[$i]['ten_hh'] ?></a></h5>
                                        <p class="card-text">Giá: <span style="color: red;"><?= $data[$i]['don_gia'] ?>$</span> </p>
                                        <!-- <a href="" class="btn btn-primary">BUY NOW</a> -->
                                        <form method="POST" action="/trongtdph17510_ass/SourceFile/cart/cart.php" enctype="multipart/form-data">
                                            <input type="hidden" value="<?= $data[$i]['ten_hh'] ?>" name="ten_hh" />
                                            <input type="hidden" value="<?= $data[$i]['don_gia'] ?>" name="don_gia" />
                                            <input type="hidden" value="<?= $data[$i]['hinh'] ?>" name="hinh" />
                                            <input type="hidden" value="<?= $data[$i]['ma_hh'] ?>" name="ma_hh" />
                                            <input type="hidden" name="so_luong" value="1" />
                                            <input name="addcart" id="" class="btn btn-primary" type="submit" value="Mua sản phẩm">
                                        </form>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>

                    </div>
                </div>
                <div class="products">
                    <h3 class="heading-prd">Sản phẩm mới nhất</h3>
                    <div class="grid_row">
                        <?php for ($i = 0; $i < count($new); $i++) { ?>
                            <div class="g-col-4" style="margin-bottom: 10px;">
                                <div class="card" style="width: 18rem;">
                                    <a href="./../home/chi-tiet.php?ma_hh=<?= $new[$i]['ma_hh'] ?>"><img src="./../content/img/<?= $new[$i]['hinh'] ?>" class="card-img-top" alt="..."></a>
                                    <div class="text-center card-body">
                                        <h5 class="card-title" style="min-height: 50px;"><a href="./../home/chi-tiet.php?ma_hh=<?= $new[$i]['ma_hh'] ?>"><?= $new[$i]['ten_hh'] ?></a></h5>
                                        <p class="card-text">Giá: <span style="color: red;"><?= $new[$i]['don_gia'] ?>$</span> </p>
                                        <form method="POST" action="/trongtdph17510_ass/SourceFile/cart/cart.php" enctype="multipart/form-data">
                                            <input type="hidden" value="<?= $new[$i]['ten_hh'] ?>" name="ten_hh" />
                                            <input type="hidden" value="<?= $new[$i]['don_gia'] ?>" name="don_gia" />
                                            <input type="hidden" value="<?= $new[$i]['hinh'] ?>" name="hinh" />
                                            <input type="hidden" value="<?= $new[$i]['ma_hh'] ?>" name="ma_hh" />
                                            <input type="hidden" name="so_luong" value="1" />
                                            <input name="addcart" id="" class="btn btn-primary" type="submit" value="Mua sản phẩm">
                                        </form>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>

                    </div>
                </div>
                <div class="post">
                    <h1>New Post</h1>
                    <div class="row">
                        <img class="img" width="50px" src="./../content/img/<?= $post['hinh'] ?>" alt="">
                        <div class="text" style="padding: 80px;">
                            <p><?= $post['mo_ta'] ?></p>
                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="text" style="padding: 80px;">
                            <p><?= $post1['mo_ta'] ?></p>
                        </div>
                        <img class="img" src="./../content/img/<?= $post1['hinh'] ?>" alt="">
                    </div>
                </div>
            </div>

        </div>
    </div>
</body>

</html>