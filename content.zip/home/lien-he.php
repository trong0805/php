<!DOCTYPE html>
<html>

<body>
    <h2 style="text-align: center;">LIÊN HỆ</h2>
    <div style="width: 1200px; margin: 0 auto;"><iframe style="width: 1200px;" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d13272.550189356549!2d105.78947276534987!3d21.01333685754019!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3135aca0ab3d8965%3A0xf1d58d4091c14ee2!2zTmfDtSAxMTAgVHLhuqduIER1eSBIxrBuZywgVHJ1bmcgSG_DoCwgQ-G6p3UgR2nhuqV5LCBIw6AgTuG7mWksIFZpZXRuYW0!5e0!3m2!1sen!2s!4v1632973627298!5m2!1sen!2s" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe></div>
    <div style="text-align: center; width: 50%; margin: 0 auto;">
        <h2 style="text-align: center;">FORM LIÊN HỆ</h2>
        <form>
        <div class="mb-3">
            <label for="exampleFormControlInput1" class="form-label">Email address</label>
            <input type="email" class="form-control" id="exampleFormControlInput1" placeholder="name@example.com">
        </div>
        <div class="mb-3">
            <label for="exampleFormControlTextarea1" class="form-label">Example textarea</label>
            <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
        </div>
        <div class="col-auto">
            <button type="submit" class="btn btn-primary mb-3">Send</button>
        </div>
        </form>
    </div>
</body>

</html>