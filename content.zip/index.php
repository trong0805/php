<?php
header("location: home");