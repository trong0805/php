<?php
require_once './../db/dbhang-hoa.php';
$data = getall();
?>
<!DOCTYPE html>
<html>

<body>
<?php require_once './../db/nav_admin.php'; ?>
    <hr>
    <h2 class="alert alert-danger">QUẢN LÝ HÀNG HÓA</h2>
    <?= $MESSAGE ?>
    <table class="table" border="1">
        <thead>
            <tr>
                <th>Mã</th>
                <th>Tên</th>
                <th>Đơn giá</th>
                <th>Giảm giá</th>
                <th>Hình ảnh</th>
                <th>Ngày nhập</th>
                <th>Mô tả</th>
                <th>Lượt xem</th>
                <th>Loại</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($data as $ds) { extract($ds); ?>
                <tr>
                    <td><?=$ma_hh?></td>
                    <td><?=$ten_hh?></td>
                    <td><?=$don_gia?></td>
                    <td><?=$giam_gia?></td>
                    <td><img width="60px" src="./../../content/img/<?=$hinh?>" alt=""></td>
                    <td><?=$ngay_nhap?></td>
                    <td><?=$mo_ta?></td>
                    <td><?=$so_luot_xem?></td>
                    <td><?=$ten_loai?></td>
                    <td>
                        <a href="/trongtdph17510_ass/SourceFile/admin/hang-hoa/update.php?ma_hh=<?=$ma_hh?>" class="btn btn-primary m-1">Sửa</a>
                        <a href="/trongtdph17510_ass/SourceFile/admin/hang-hoa/delete.php?ma_hh=<?=$ma_hh?>" class="btn btn-primary m-1" onclick="return confirm('Bạn muốn xóa mặt hàng này?');">Xóa</a>
                    </td>
                </tr>
            <?php } ?>
        </tbody>
        
    </table>
    <a href="/trongtdph17510_ass/SourceFile/admin/hang-hoa/?btn_edit" class="btn btn-primary m-1">Thêm mới</a>
</body>

</html>