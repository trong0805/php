<?php
session_start();
require_once './../db/dbhang-hoa.php';
$data = getall1();
$id = $_GET['ma_hh'];
$data2 = getid($id);

?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>Web design sample project</title>
    <!--jQuery-->
    <!-- <script src="/trongtdph17510_ass/SourceFile/content/js/jquery.m/in.js"></script> -->
    <!--Bootstrap-->
    <!-- <script src=""></script> -->
    <link href="/trongtdph17510_ass/SourceFile/content/css/bootstrap.min.css" rel="stylesheet" />
</head>

<body class="container">
    <?php require_once './../../header.php'; ?>
    <?php require_once './../db/nav_admin.php'; ?>
    <hr>
    <h2 class="alert alert-danger">QUẢN LÝ HÀNG HÓA</h2>
    <form action="/trongtdph17510_ass/SourceFile/admin/hang-hoa/edit_update.php?ma_hh=<?= $data2['ma_hh'] ?>" method="post" enctype="multipart/form-data">
        <fieldset>
            <div class="mb-3">
                <label for="disabledTextInput" class="form-label">Mã khách hàng</label>
                <input style="background-color: rgba( 0, 0, 0, 0.3);" id="disabledTextInput" name="ma_hh" class="form-control" placeholder="Auto number" value="<?= $data2['ma_hh'] ?>">
            </div>
        </fieldset>
        <div class="form-group">
            <label>Tên hàng hóa</label>
            <input type="text" name="ten_hh" value="<?= $data2['ten_hh'] ?>" class="form-control">
        </div>
        <div class="form-group">
            <label>Đơn giá</label>
            <input type="number" name="don_gia" value="<?= $data2['don_gia'] ?>" class="form-control">
        </div>
        <div class="form-group">
            <label>Giảm giá</label>
            <input type="number" name="giam_gia" value="<?= $data2['giam_gia'] ?>" class="form-control">
        </div>
        <div class="form-group">
            <label>Hình ảnh</label> <br>
            <img width="300px" src="./../../content/img/<?= $data2['hinh'] ?>" alt="">
            <input type="file" name="hinh" value="<?= $data2['hinh'] ?>" class="form-control">
        </div>
        <div class="form-group">
            <label>Ngày nhập</label>
            <input type="date" name="ngay_nhap" value="<?= $data2['ngay_nhap'] ?>" class="form-control">
        </div>
        <div class="form-group">
            <label>Mô tả</label>
            <input type="text" name="mo_ta" value="<?= $data2['mo_ta'] ?>" class="form-control">
        </div>
        <div class="form-group">
            <label>Lượt xem</label>
            <input type="number" name="so_luot_xem" value="<?= $data2['so_luot_xem'] ?>" class="form-control">
        </div>
        <div class="form-group">
            <label for="">Tên loại</label>
            <select class="form-control" name="ma_loai" id="">
                <?php foreach ($data as $ds) {
                    extract($ds); ?>
                    <option value="<?= $ma_loai ?>>"><?= $ten_loai ?></option>
                <?php } ?>
            </select>
        </div>
        <p style="color:red;">
            <?php if (isset($_SESSION['error'])){
                echo $_SESSION['error'];
                unset($_SESSION['error']);
            }
            ?>
        </p>
        <div class="form-group">
            <button name="btn_save" class="btn btn-primary m-1">Sửa</button>
            <a href="/trongtdph17510_ass/SourceFile/admin/khach-hang?btn_list" class="btn btn-primary m-1">Danh sách</a>
        </div>
    </form>
    <?php require_once './../../footer.php'; ?>
</body>

</html>