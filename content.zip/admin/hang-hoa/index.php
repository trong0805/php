<?php
$MESSAGE = "";
if (array_key_exists("btn_list", $_REQUEST)) {
    $VIEW_NAME = "admin/hang-hoa/list.php";
} else if (array_key_exists("btn_edit", $_REQUEST)) {
    $VIEW_NAME = "admin/hang-hoa/edit.php";
} else if (array_key_exists("btn_save", $_REQUEST)) {
    $MESSAGE = "Cập nhật thông tin hàng hóa thành công!";
    $VIEW_NAME = "admin/hang-hoa/edit.php";
} else if (array_key_exists("btn_delete", $_REQUEST)) {
    $MESSAGE = "Xóa hàng hóa thành công!";
    $VIEW_NAME = "admin/hang-hoa/list.php";
} else {
    $VIEW_NAME = "admin/hang-hoa/list.php";
}
require './../../layout.php';

