<?php
session_start();
require_once './../db/dbhang-hoa.php';

if (
    empty($_POST['ten_hh']) ||
    empty($_POST['don_gia']) ||
    empty($_POST['giam_gia']) ||
    empty($_FILES['hinh']['name']) ||
    empty($_POST['ngay_nhap']) ||
    empty($_POST['mo_ta']) ||
    empty($_POST['so_luot_xem'])
) {
    $_SESSION['error'] = "không bỏ trống thông tin!";
    header("location: /trongtdph17510_ass/SourceFile/admin/hang-hoa/?btn_edit");
    die;
}

if (!is_int($_POST['don_gia']) && $_POST['don_gia'] < 0) 
{
    $_SESSION['error'] = "Đơn giá là số dương!";
    header("location: /trongtdph17510_ass/SourceFile/admin/hang-hoa/?btn_edit");
    die;
}

if (!is_int($_POST['giam_gia']) && $_POST['giam_gia'] < 0) 
{
    $_SESSION['error'] = "Giảm giá là số dương!";
    header("location: /trongtdph17510_ass/SourceFile/admin/hang-hoa/?btn_edit");
    die;
}
if (!is_int($_POST['so_luot_xem']) && $_POST['so_luot_xem'] < 0) 
{
    $_SESSION['error'] = "Số lượt xem là số dương!";
    header("location: /trongtdph17510_ass/SourceFile/admin/hang-hoa/?btn_edit");
    die;
}
$data = [
    'ten_hh' => $_POST['ten_hh'],
    'don_gia' => $_POST['don_gia'],
    'giam_gia' => $_POST['giam_gia'],
    'hinh' => $_FILES['hinh']['name'],
    'ngay_nhap' => $_POST['ngay_nhap'],
    'mo_ta' => $_POST['mo_ta'],
    'so_luot_xem' => $_POST['so_luot_xem'],
    'ma_loai' => $_POST['ma_loai']
];

if (isset($_FILES['hinh'])) {
    $file = $_FILES['hinh'];
    $file_name = $file['name'];
    move_uploaded_file($file['tmp_name'], './../../content/img/' . $file_name);
}

if(empty($_FILES['hinh']) === false) {
    $file_name = $_FILES['hinh']['name'];
    if($_FILES['hinh']['size'] > 5072000){
        $_SESSION['error'] = "dung lượng ảnh dưới 3M!";
        header("location: /trongtdph17510_ass/SourceFile/admin/hang-hoa/?btn_edit");
        die;
    }
    if(strpos( $_FILES['hinh']['type'], 'image') ===false) {
        $_SESSION['error'] = "Phải là ảnh!";
        header("location: /trongtdph17510_ass/SourceFile/admin/hang-hoa/?btn_edit");
        die;
    }
}
insert($data);
header("Location: /trongtdph17510_ass/SourceFile/admin/hang-hoa/?btn_list");
