<?php  
    require_once './../db/dbhang-hoa.php';

    $id = $_GET['ma_hh'];
    delete($id);
    header("Location: /trongtdph17510_ass/SourceFile/admin/hang-hoa/?btn_list");

?>