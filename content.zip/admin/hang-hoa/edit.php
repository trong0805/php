<?php
// session_start();
require_once './../db/dbhang-hoa.php';
$data = getall1();
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>Web design sample project</title>
    <!--jQuery-->
    <!-- <script src="/xshop/SourceFile/content/js/jquery.m/in.js"></script> -->
    <!--Bootstrap-->
    <!-- <script src=""></script> -->
    <link href="/xshop/SourceFile/content/css/bootstrap.min.css" rel="stylesheet" />
</head>

<body class="container">
<?php require_once './../db/nav_admin.php'; ?>
    <hr>
    <h2 class="alert alert-danger">QUẢN LÝ HÀNG HÓA</h2>
    <?= $MESSAGE ?>
    <form action="/trongtdph17510_ass/SourceFile/admin/hang-hoa/edit_insert.php" method="POST" enctype="multipart/form-data">
        <fieldset disabled>
            <div class="mb-3">
                <label for="disabledTextInput" class="form-label">Mã hàng hóa</label>
                <input  id="disabledTextInput" name="ma_hh" class="form-control" placeholder="Disabled input">
            </div>
        </fieldset>
        <div class="form-group">
            <label>Tên hàng hóa</label>
            <input type="text" name="ten_hh" class="form-control">
        </div>
        <div class="form-group">
            <label>Đơn giá</label>
            <input type="number"name="don_gia" class="form-control">
        </div>
        <div class="form-group">
            <label>Giảm giá</label>
            <input  type="number" name="giam_gia" class="form-control">
        </div>
        <div class="form-group">
            <label>Hình ảnh</label>
            <input type="file" name="hinh" class="form-control">
        </div>
        <div class="form-group">
            <label>Ngày nhập</label>
            <input  type="date" name="ngay_nhap" class="form-control">
        </div>
        <div class="form-group">
            <label>Mô tả</label>
            <input  type="text" name="mo_ta" class="form-control">
        </div>
        <div class="form-group">
            <label>Lượt xem</label>
            <input  type="number" name="so_luot_xem" class="form-control">
        </div>
        <div class="form-group">
            <label>Loại</label>
            <select  name="ma_loai" class="form-control">
                <?php foreach ($data as $ds) { extract($ds); ?>
                    <option value="<?=$ma_loai?>>"><?=$ten_loai?></option>
                <?php } ?>
            </select>
        </div>
        <p style="color:red;">
            <?php if (isset($_SESSION['error'])){
                echo $_SESSION['error'];
                unset($_SESSION['error']);
            }
            ?>
        </p>
        <div class="form-group">
            <button name="" class="btn btn-primary m-1">Lưu</button>
            <button type="reset" class="btn btn-primary m-1">Nhập lại</button>
            <a href="/xshop/SourceFile/admin/hang-hoa?btn_list" class="btn btn-primary m-1">Danh sách</a>
        </div>
    </form>
    
</body>

</html>