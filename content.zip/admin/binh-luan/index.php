<?php
$MESSAGE = "";
if (array_key_exists("btn_list", $_REQUEST)) {
    $VIEW_NAME = "admin/binh-luan/list.php";
} else if (array_key_exists("btn_delete", $_REQUEST)) {
    $MESSAGE = "Xóa hàng hóa thành công!";
    $VIEW_NAME = "admin/binh-luan/list.php";
} else {
    $VIEW_NAME = "admin/binh-luan/list.php";
}
require './../../layout.php';

