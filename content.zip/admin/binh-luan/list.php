<?php
require_once './../db/dbhang-hoa.php';
require_once './../db/dbbinh-luan.php';
// $data_bl = getbl_hh();
$data_bl = getall_bl();
// $data_bl_name = getall_bl();
?>
<!DOCTYPE html>
<html>

<body>
    <?php require_once './../db/nav_admin.php'; ?>
    <hr>
    <h2 class="alert alert-danger">QUẢN LÝ Bình Luận</h2>
    <?= $MESSAGE ?>
    <table class="table" border="1">
        <thead>
            <tr>
                <th scope="col">Mã bình luận</th>
                <th scope="col">Nội dung</th>
                <th scope="col">Tên hàng hóa</th>
                <th scope="col">Loại hàng</th>
                <th scope="col">Tên khách hàng</th>
                <th scope="col">Ngày bình luận</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($data_bl as $bl) {
                extract($bl) ?>
                <tr>
                    <td><?= $ma_bl ?></td>
                    <td><?= $noi_dung ?></td>
                    <td><?= $ten_hh ?></td>
                    <td><?= $ma_loai ?></td>
                    <td><?= $ho_ten ?></td>
                    <td><?= $ngay_bl ?></td>
                    <td>
                        <a href="/trongtdph17510_ass/SourceFile/home/chi-tiet.php?ma_hh=<?=$ma_hh?>" class="btn btn-primary m-1">Đến bình luận</a>
                        <a href="/trongtdph17510_ass/SourceFile/admin/binh-luan/delete_ad.php?ma_bl=<?=$ma_bl?>" class="btn btn-primary m-1" onclick="return confirm('Bạn muốn xóa bình luận này?');">Xóa</a>
                    </td>

                </tr>
            <?php } ?>
        </tbody>
    </table>
    </div>
    </div>
    </table>
</body>

</html>