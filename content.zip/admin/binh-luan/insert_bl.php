<?php

require_once './../db/dbhang-hoa.php';
require_once './../db/dbbinh-luan.php';
$id = $_GET['ma_hh'];

$data = [
    'ma_bl' => $_POST['ma_bl'],
    'noi_dung' => $_POST['noi_dung'],
    'ma_hh' => $_POST['ma_hh'],
    'ma_kh' => $_POST['ma_kh'],
    'ngay_bl' => $_POST['ngay_bl']
];
insert_bl($data);
header("location: /trongtdph17510_ass/SourceFile/home/chi-tiet.php?ma_hh=$id");
