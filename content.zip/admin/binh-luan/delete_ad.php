<?php 
    require_once './../db/dbhang-hoa.php';
    require './../db/dbbinh-luan.php';

    $id = $_GET['ma_bl'];
    $ma_hh = getall_id($id);
    $ma = $ma_hh['ma_hh'];
    delete_bl($id);
    header("location: /trongtdph17510_ass/SourceFile/admin/binh-luan/");
?>