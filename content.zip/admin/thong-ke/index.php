<?php
$MESSAGE = "";
if (array_key_exists("btn_list", $_REQUEST)) {
    $VIEW_NAME = "admin/thong-ke/list.php";
} else if (array_key_exists("thongke", $_REQUEST)) {
    $VIEW_NAME = "admin/thong-ke/thongke.php";
} else {
    $VIEW_NAME = "admin/thong-ke/list.php";
}
require './../../layout.php';

