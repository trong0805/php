<?php
require_once './../db/dbloai-hang.php';
$data = getAlldm();
?>
<!DOCTYPE html>
<html>

<body>
    <?php require_once './../db/nav_admin.php'; ?>
    <hr>
    <h2 class="alert alert-danger">QUẢN LÍ THỐNG KÊ</h2>
    <!-- <?= $MESSAGE ?> -->
    <div class="formloaihang">

        <a href="/trongtdph17510_ass/SourceFile/admin/thong-ke/?btn_list" class="btn btn-primary mb-1">Danh mục Thống kê</a>
        <div id="piechart"></div>
        <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
        <script type="text/javascript">
            // Load google charts
            google.charts.load('current', {
                'packages': ['corechart']
            });
            google.charts.setOnLoadCallback(drawChart);

            // Draw the chart and set the chart values
            function drawChart() {
                var data = google.visualization.arrayToDataTable([

                    ['Danh mục', 'Số lượng sản phẩm'],
                    <?php
                    $tongdm = count($data);
                    $i = 1;
                    foreach ($data as $thongke) {
                        extract($thongke);
                        if ($i == $tongdm) $dauphay = "";
                        else $dauphay = ",";
                        echo "['" . $thongke['namedm'] . "'," . $thongke['countsp'] . " ]" . $dauphay;
                        $i += 1;
                    }
                    ?>
                ]);

                // Optional; add a title and set the width and height of the chart
                var options = {
                    'title': 'Biểu đồ',
                    'width': 1000,
                    'height': 800
                };

                // Display the chart inside the <div> element with id="piechart"
                var chart = new google.visualization.PieChart(document.getElementById('piechart'));
                chart.draw(data, options);
            }
        </script>

    </div>
</body>

</html>