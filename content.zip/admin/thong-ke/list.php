<?php
require_once './../db/dbloai-hang.php';
$data = getAlldm();
?>
<!DOCTYPE html>
<html>

<body>
    <?php require_once './../db/nav_admin.php'; ?>
    <hr>
    <h2 class="alert alert-danger">QUẢN LÍ THỐNG KÊ</h2>
    <!-- <?= $MESSAGE ?> -->
    <table class="table" border="1">

        <tr>
            <th>Mã danh mục</th>
            <th>Tên danh mục</th>
            <th>Số lượng</th>
            <th>Giá thấp nhất</th>
            <th>Giá cao nhất</th>
            <th>Giá trung bình</th>
        </tr>
        <?php for ($i = 0; $i < count($data); $i++) { ?>
            <tr>
                <td>
                    <?php echo $data[$i]['iddm'] ?>
                </td>
                <td>
                    <?php echo $data[$i]['namedm'] ?>
                </td>
                <td>
                    <?php echo $data[$i]['countsp'] ?>
                </td>
                <td>
                    <?php echo $data[$i]['minprice'] ?>
                </td>
                <td>
                    <?php echo $data[$i]['maxprice'] ?>
                </td>
                <td>
                    <?php echo $data[$i]['tbprice'] ?>
                </td>
            </tr>
        <?php } ?>

    </table>
    <a href="/trongtdph17510_ass/SourceFile/admin/thong-ke/?thongke" class="btn btn-primary mb-1">Thống kê</a>
</body>

</html>