<?php
session_start();
require_once './../db/dbkhach-hang.php';
if(
    empty($_POST['mat_khau']) ||
    empty($_POST['ho_ten']) ||
    empty($_FILES['hinh']['name']) ||
    empty($_POST['email']) 
){
    $_SESSION['error'] = "không bỏ trống thông tin!";
    header("location: /trongtdph17510_ass/SourceFile/admin/khach-hang/?btn_edit");
    die;
}
// if (!is_int($_POST['kich_hoat']) && $_POST['kich_hoat'] < 0) 
// {
//     $_SESSION['error'] = "Số lượt xem là số dương!";
//     header("location: /trongtdph17510_ass/SourceFile/admin/hang-hoa/?btn_edit");
//     die;
// }
$data = [
    'mat_khau' => $_POST['mat_khau'],
    'ho_ten' => $_POST['ho_ten'],
    'kich_hoat' => $_POST['kich_hoat'],
    'hinh' => $_FILES['hinh']['name'],
    'email' => $_POST['email'],
    'vai_tro' => $_POST['vai_tro']
];

if (isset($_FILES['hinh'])) {
    $file = $_FILES['hinh'];
    $file_name = $file['name'];
    move_uploaded_file($file['tmp_name'], './../../content/img/' . $file_name);
}
if(empty($_FILES['hinh']) === false) {
    $file_name = $_FILES['hinh']['name'];
    if($_FILES['hinh']['size'] > 5072000){
        $_SESSION['error'] = "dung lượng ảnh dưới 3M!";
        header("location: /trongtdph17510_ass/SourceFile/admin/khach-hang/?btn_edit");
        die;
    }
    if(strpos( $_FILES['hinh']['type'], 'image') ===false) {
        $_SESSION['error'] = "Phải là ảnh!";
        header("location: /trongtdph17510_ass/SourceFile/admin/khach-hang/?btn_edit");
        die;
    }
}
insert($data);
header("Location: /trongtdph17510_ass/SourceFile/admin/khach-hang/?btn_list");
