<?php
session_start();
require_once './../db/dbkhach-hang.php';
$id = $_GET['ma_kh'];
$data = getid($id);
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>Web design sample project</title>
    <!--jQuery-->
    <!-- <script src="/trongtdph17510_ass/SourceFile/content/js/jquery.m/in.js"></script> -->
    <!--Bootstrap-->
    <!-- <script src=""></script> -->
    <link href="/trongtdph17510_ass/SourceFile/content/css/bootstrap.min.css" rel="stylesheet" />
</head>

<body class="container">
    <?php require_once './../../header.php'; ?>
    <?php require_once './../db/nav_admin.php'; ?>
    <hr>
    <h2 class="alert alert-danger">QUẢN LÝ KHÁCH HÀNG</h2>
    <form action="/trongtdph17510_ass/SourceFile/admin/khach-hang/edit_update.php?ma_kh=<?= $data['ma_kh'] ?>" method="post" enctype="multipart/form-data">
        <fieldset>
            <div class="mb-3">
                <label for="disabledTextInput" class="form-label">Mã khách hàng</label>
                <input style="background-color: rgba( 0, 0, 0, 0.3);" id="disabledTextInput" name="ma_kh" class="form-control" placeholder="Auto number" value="<?= $data['ma_kh'] ?>">
            </div>
        </fieldset>
        <div class="form-group" hidden>
            <label>Mật khẩu</label>
            <input type="password" name="mat_khau" value="<?= $data['mat_khau'] ?>" class="form-control">
        </div>
        <div class="form-group">
            <label>Họ tên</label>
            <input type="text" name="ho_ten" value="<?= $data['ho_ten'] ?>" class="form-control">
        </div>
        <div class="form-group">
            <label>Kích hoạt</label>
            <select class="form-control"  name="kich_hoat" id="" >
                <option value="0">Hoạt động</option>
                <option value="1">Vô hiệu hóa</option>
            </select>
        </div>
        <div class="form-group">
            <label>Hình ảnh</label> <br>
            <img width="300px" src="./../../content/img/<?= $data['hinh'] ?>" alt="">
            <input type="file" name="hinh" value="<?= $data['hinh'] ?>" class="form-control">
        </div>
        <div class="form-group">
            <label>Email</label>
            <input type="email" name="email" value="<?= $data['email'] ?>" class="form-control">
        </div>
        <div class="form-group">
            <label for="">Vai trò</label>
            <select class="form-control" name="vai_tro" id="">
                <option value="0">admin</option>
                <option value="1">khách hàng</option>


            </select>
        </div>
        <p style="color:red;">
            <?php if (isset($_SESSION['error'])) {
                echo $_SESSION['error'];
                unset($_SESSION['error']);
            }
            ?>
        </p>
        <div class="form-group">
            <button name="btn_save" class="btn btn-primary m-1">Sửa</button>
            <a href="/trongtdph17510_ass/SourceFile/admin/khach-hang?btn_list" class="btn btn-primary m-1">Danh sách</a>
        </div>
    </form>
    <?php require_once './../../footer.php'; ?>
</body>

</html>