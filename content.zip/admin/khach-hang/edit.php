<!-- <?php session_start(); ?> -->
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>Web design sample project</title>
    <!--jQuery-->
    <!-- <script src="/trongtdph17510_ass/SourceFile/content/js/jquery.m/in.js"></script> -->
    <!--Bootstrap-->
    <!-- <script src=""></script> -->
    <link href="/trongtdph17510_ass/SourceFile/content/css/bootstrap.min.css" rel="stylesheet" />
</head>

<body class="container">
    <?php require_once './../db/nav_admin.php'; ?>
    <hr>
    <h2 class="alert alert-danger">QUẢN LÝ KHÁCH HÀNG</h2>
    <?= $MESSAGE ?>
    <form action="/trongtdph17510_ass/SourceFile/admin/khach-hang/edit_insert.php" method="POST" enctype="multipart/form-data">
        <fieldset>
            <div class="mb-3" disabled>
                <label for="disabledTextInput" class="form-label">Mã Khách hàng</label>
                <input style="background-color: rgba( 0, 0, 0, 0.2);" id="disabledTextInput" name="ma_kh" class="form-control" placeholder="Auto number">
            </div>
        </fieldset>
        <div class="form-group">
            <label>Mật khẩu</label>
            <input type="password" name="mat_khau" class="form-control">
        </div>
        <div class="form-group">
            <label>Họ tên</label>
            <input type="text" name="ho_ten" class="form-control">
        </div>
        <div class="form-group">
            <label>Kích hoạt</label>
            <select class="form-control" name="kich_hoat" id="">
                <option value="0">Hoạt động</option>
                <option value="1">Vô hiệu hóa</option>
            </select>
        </div>
        <div class="form-group">
            <label>Hình ảnh</label>
            <input type="file" name="hinh" class="form-control">
        </div>
        <div class="form-group">
            <label>Email</label>
            <input type="email" name="email" class="form-control">
        </div>
        <div class="form-group">
            <label for="">Vai trò</label>
            <select class="form-control" name="vai_tro" id="">
                <option value="0">Admin</option>
                <option value="1">Khách Hàng</option>
            </select>
        </div>
        <p style="color:red;">
            <?php if (isset($_SESSION['error'])) {
                echo $_SESSION['error'];
                unset($_SESSION['error']);
            }
            ?>
        </p>
        <div class="form-group">
            <button name="btn_save" class="btn btn-primary m-1">Lưu</button>
            <button type="reset" class="btn btn-primary m-1">Nhập lại</button>
            <a href="/trongtdph17510_ass/SourceFile/admin/khach-hang?btn_list" class="btn btn-primary m-1">Danh sách</a>
        </div>
    </form>
</body>

</html>