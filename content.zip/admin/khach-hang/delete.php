<?php  
    require_once './../db/dbkhach-hang.php';

    $id = $_GET['ma_kh'];
    delete($id);
    header("Location: /trongtdph17510_ass/SourceFile/admin/khach-hang/?btn_list");

?>