<?php
$MESSAGE = "";
if (array_key_exists("btn_list", $_REQUEST)) {
    $VIEW_NAME = "admin/khach-hang/list.php";
} else if (array_key_exists("btn_edit", $_REQUEST)) {
    $VIEW_NAME = "admin/khach-hang/edit.php";
} else if (array_key_exists("btn_save", $_REQUEST)) {
    $MESSAGE = "Cập nhật thông tin hàng hóa thành công!";
    $VIEW_NAME = "admin/khach-hang/edit.php";
} else if (array_key_exists("btn_delete", $_REQUEST)) {
    $MESSAGE = "Xóa hàng hóa thành công!";
    $VIEW_NAME = "admin/khach-hang/list.php";
} else {
    $VIEW_NAME = "admin/khach-hang/list.php";
}
require './../../layout.php';

