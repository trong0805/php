<?php
require_once './../db/dbkhach-hang.php';
$data = getall();
?>
<!DOCTYPE html>
<html>

<body>
    <?php require_once './../db/nav_admin.php'; ?>
    <hr>
    <h2 class="alert alert-danger">QUẢN LÝ TÀI KHOẢN </h2>
    <?= $MESSAGE ?>
    <table class="table" border="1">
        <thead>
            <tr>
                <th>Mã khách hàng</th>
                <th>Tên</th>
                <th>Kích hoạt</th>
                <th>Hình ảnh</th>
                <th>Email</th>
                <th>Vai trò</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($data as $datas) { ?>
                <tr>
                    <td><?= $datas['ma_kh'] ?></td>
                    <td><?= $datas['ho_ten'] ?></td>
                    <td><?php if ($datas['kich_hoat'] == 0) {
                            echo "Hoạt động";
                        } else {
                            echo "Vô hiệu hóa";
                        } ?></td>
                    <td><img width="60px" src="./../../content/img/<?= $datas['hinh'] ?>" alt=""></td>
                    <td><?= $datas['email'] ?> </td>
                    <td><?php if ($datas['vai_tro'] == 0) {
                            echo "admin";
                        } else {
                            echo "khách hàng";
                        } ?></td>
                    <td>
                        <?php if ($datas['vai_tro'] == 1) { ?>
                            <a href="/trongtdph17510_ass/SourceFile/admin/khach-hang/update.php?ma_kh=<?= $datas['ma_kh'] ?>" class="btn btn-primary m-1">Sửa</a>
                            <a href="/trongtdph17510_ass/SourceFile/admin/khach-hang/delete.php?ma_kh=<?= $datas['ma_kh'] ?>" class="btn btn-primary m-1" onclick="return confirm('Bạn muốn xóa tài khoản này!');">Xóa</a>
                        <?php } else {
                        } ?>
                    </td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
    <a href="/trongtdph17510_ass/SourceFile/admin/khach-hang/?btn_edit" class="btn btn-primary m-1">Thêm mới</a>
</body>

</html>