<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Title</title>
</head>

<body>
    <nav class="navbar navbar-expand-sm bg-light navbar-light" style="display: flex; justify-content: center;">
        <a class="btn btn-primary m-1" role="button" href="/trongtdph17510_ass/SourceFile/admin/hang-hoa/index.php">Quản lí Hàng hóa</a>
        <a class="btn btn-primary m-1" role="button" href="/trongtdph17510_ass/SourceFile/admin/khach-hang/index.php">Quản lí Tài Khoản</a>
        <a class="btn btn-primary m-1" role="button" href="/trongtdph17510_ass/SourceFile/admin/binh-luan/index.php">Quản lí Bình luận</a>
        <a class="btn btn-primary m-1" role="button" href="/trongtdph17510_ass/SourceFile/admin/loai-hang/index.php">Quản lí Loại hàng</a>
        <a class="btn btn-primary m-1" role="button" href="/trongtdph17510_ass/SourceFile/admin/thong-ke/index.php">Quản lí Thống kê</a>
    </nav>
</body>

</html>