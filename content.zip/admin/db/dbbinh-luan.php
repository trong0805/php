<?php
// function connect()
// {
//     $dbhost = ("mysql:host=localhost; dbname=duan_xshop");
//     $dbuser = "root";
//     $dbpass = "";
//     $conn = new PDO($dbhost, $dbuser, $dbpass);
//     // $conn -> setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
//     return $conn;
// }
function getall_bl()
{
    $conn = connect();
    $sql = "SELECT * FROM binh_luan inner join hang_hoa on binh_luan.ma_hh = hang_hoa.ma_hh inner join khach_hang on binh_luan.ma_kh = khach_hang.ma_kh";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    $result = [];
    while (true) {
        $data = $stmt->fetch();
        if ($data == false) {
            break;
        }
        $row = [
            'ma_bl' => $data['ma_bl'],
            'ma_hh' => $data['ma_hh'],
            'ma_kh' => $data['ma_kh'],
            'noi_dung' => $data['noi_dung'],
            'ten_hh' => $data['ten_hh'],
            'ma_loai' => $data['ma_loai'],
            'ho_ten' => $data['ho_ten'],
            'ngay_bl' => $data['ngay_bl']
        ];
        array_push($result, $row);
    }
    return $result;
}
function getbl_hh(){
    $conn = connect();
    $sql = "SELECT * FROM hang_hoa inner join loai_hang on hang_hoa.ma_loai = loai_hang.ma_loai inner join binh_luan on hang_hoa.ma_hh = binh_luan.ma_hh";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    $result = [];
    while(true){
        $data = $stmt->fetch();
        if ($data == false) {
            break;
        }
        $row = [
            'ma_bl' => $data['ma_bl'],
            'ma_hh' => $data['ma_hh'],
            'noi_dung' => $data['noi_dung'],
            'ten_hh' => $data['ten_hh'],
            'ten_loai' => $data['ten_loai'],
            'ngay_bl' => $data['ngay_bl']
        ];
        array_push($result, $row);
    }
    return $result;
}
function getall_id($id)
{
    $conn = connect();
    $sql = "SELECT * FROM binh_luan where ma_bl = :ma_bl";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['ma_bl' => $id]);
        $data = $stmt->fetch();
        
        $row = [
            'ma_bl' => $data['ma_bl'],
            'ma_hh' => $data['ma_hh'],
            'ma_kh' => $data['ma_kh'],
            'noi_dung' => $data['noi_dung'],
            'ngay_bl' => $data['ngay_bl']
        ];
    return $row;
}
function getall_bl_id($id)
{
    $conn = connect();
    $sql = "SELECT * FROM binh_luan inner join khach_hang on binh_luan.ma_kh = khach_hang.ma_kh where ma_hh = :ma_hh";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['ma_hh' => $id]);
    $result = [];
    while (true) {
        $data = $stmt->fetch();
        if ($data == false) {
            break;
        }
        $row = [
            'ma_bl' => $data['ma_bl'],
            'ma_hh' => $data['ma_hh'],
            'hinh' => $data['hinh'],
            'noi_dung' => $data['noi_dung'],
            'ma_kh' => $data['ma_kh'],
            'ho_ten' => $data['ho_ten'],
            'ngay_bl' => $data['ngay_bl']
        ];
        array_push($result, $row);
    }
    return $result;
}

function insert_bl(array $data)
{
    $conn = connect();
    $sql = "INSERT INTO binh_luan( ma_bl, noi_dung, ma_hh, ma_kh, ngay_bl)" .
        "VALUES( :ma_bl, :noi_dung, :ma_hh, :ma_kh, :ngay_bl)";
    $stmt = $conn->prepare($sql);
    $stmt->execute($data);
}
function update_bl($data)
{
    $conn = connect();
    $sql = "UPDATE binh_luan SET noi_dung =:noi_dung, ma_hh =:ma_hh, ma_kh =:ma_kh WHERE ma_bl = :ma_bl";
    $stmt = $conn->prepare($sql);
    $stmt->execute($data);
    return true;
}
function delete_bl($id)
{
    $conn = connect();
    $sql = "DELETE FROM binh_luan WHERE ma_bl = :ma_bl";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['ma_bl' => $id]);
}
