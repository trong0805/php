<?php
function connect()
{
    $dbhost = ("mysql:host=localhost; dbname=duan_xshop");
    $dbuser = "root";
    $dbpass = "";
    $conn = new PDO($dbhost, $dbuser, $dbpass);
    // $conn -> setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    return $conn;
}
function getall()
{
    $conn = connect();
    $sql = "SELECT * FROM loai_hang";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    // $data = $stmt->fetchAll();
    $result = [];
    while(true){
        $data = $stmt->fetch();
        if($data == false){
            break;
        }
        $row = [
            'ma_loai' => $data['ma_loai'],
            'ten_loai' => $data['ten_loai']
        ];
        array_push($result, $row);
    }
    return $result;
}
function getid($id) {
    $conn = connect();
    $sql = "SELECT * FROM loai_hang WHERE ma_loai = :ma_loai";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['ma_loai' => $id]);
    
        $data = $stmt->fetch();
        
        $row = [
            'ma_loai' => $data['ma_loai'],
            'ten_loai' => $data['ten_loai']
        ];
       
    return $row;
}
function insert(array $data) {
    $conn = connect();
    $sql = "INSERT INTO loai_hang(ten_loai) VALUES (:ten_loai)";
    $stmt = $conn->prepare($sql);
    $stmt->execute($data);
}
function update($data) {
    $conn = connect();
    $sql = "UPDATE loai_hang SET ten_loai = :ten_loai WHERE ma_loai = :ma_loai";
    $stmt = $conn -> prepare($sql);
    $stmt ->execute($data);
    return true;
}
function delete($id) {
    $conn = connect();
    $sql = "DELETE FROM loai_hang WHERE ma_loai = :ma_loai";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['ma_loai' => $id]);
}
function getAlldm() {
    $conn = connect();
    $sql = "SELECT loai_hang.ma_loai as iddm, loai_hang.ten_loai as namedm, count(hang_hoa.ma_loai) as countsp, min(hang_hoa.don_gia) as minprice, max(hang_hoa.don_gia) as maxprice, avg(hang_hoa.don_gia) as tbprice FROM hang_hoa JOIN loai_hang on loai_hang.ma_loai = hang_hoa.ma_loai GROUP BY loai_hang.ma_loai, loai_hang.ten_loai";

    //$conn->prepare($sql): tạo ra đối tượng $statement
    //statement: đối tượng giúp thực thi truy vấn
    $statement = $conn->prepare($sql);

    //thực thi truy vấn
    $statement->execute();
    

    $result = [];
    while ( true ) {
        // lấy ra dong dữ liệu tiếp theo
        $data = $statement->fetch();

        if ( $data == false ) {
            break;
        }
        $row = [
            'iddm' => $data['iddm'],
            'namedm' => $data['namedm'],
            'countsp' => $data['countsp'],
            'minprice' => $data['minprice'],
            'maxprice' => $data['maxprice'],
            'tbprice' => $data['tbprice'],
        ];

        array_push($result, $row);
    }
    return $result;
}