<?php
function connect()
{
    $dbhost = ("mysql:host=localhost; dbname=duan_xshop");
    $dbuser = "root";
    $dbpass = "";
    $conn = new PDO($dbhost, $dbuser, $dbpass);
    // $conn -> setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    return $conn;
}
function login($email, $mat_khau)
{
    $conn = connect();
    $sql = "SELECT * FROM khach_hang " .
        " WHERE email = :email AND mat_khau = :mat_khau";
    $stmt = $conn->prepare($sql);
    $params = [
        'email' => $email,
        'mat_khau' => $mat_khau
    ];

    $stmt->execute($params);
    $result = [];
    $data = $stmt->fetch();

    if ($data == false) {
        // Truy vấn không tìm đc bản ghi tương ứng hoặc truy vấn có lỗi
        return [];
    }

    $result = [
        'ma_kh' => $data['ma_kh'],
        'mat_khau' => $data['mat_khau'],
        'ho_ten' => $data['ho_ten'],
        'kich_hoat' => $data['kich_hoat'],
        'hinh' => $data['hinh'],
        'email' => $data['email'],
        'vai_tro' => $data['vai_tro']
    ];

    return $result;
}
function getall()
{
    $conn = connect();
    $sql = "SELECT * FROM khach_hang";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    // $data = $stmt->fetchAll();
    $result = [];
    while (true) {
        $data = $stmt->fetch();
        if ($data == false) {
            break;
        }
        $row = [
            'ma_kh' => $data['ma_kh'],
            'mat_khau' => $data['mat_khau'],
            'ho_ten' => $data['ho_ten'],
            'kich_hoat' => $data['kich_hoat'],
            'hinh' => $data['hinh'],
            'email' => $data['email'],
            'vai_tro' => $data['vai_tro']
        ];
        array_push($result, $row);
    }
    return $result;
}
function getid($id)
{
    $conn = connect();
    $sql = "SELECT * FROM khach_hang WHERE ma_kh = :ma_kh";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['ma_kh' => $id]);

    $data = $stmt->fetch();

    $row = [
        'ma_kh' => $data['ma_kh'],
        'mat_khau' => $data['mat_khau'],
        'ho_ten' => $data['ho_ten'],
        'kich_hoat' => $data['kich_hoat'],
        'hinh' => $data['hinh'],
        'email' => $data['email'],
        'vai_tro' => $data['vai_tro']
    ];

    return $row;
}
function insert(array $data)
{
    $conn = connect();
    $sql = "INSERT INTO khach_hang( mat_khau, ho_ten, kich_hoat, hinh, email, vai_tro) VALUES ( :mat_khau, :ho_ten, :kich_hoat, :hinh, :email, :vai_tro)";
    $stmt = $conn->prepare($sql);
    $stmt->execute($data);
}
function insert_register(array $data)
{
    $conn = connect();
    $sql = "INSERT INTO khach_hang( mat_khau, ho_ten, kich_hoat, hinh, email, vai_tro) VALUES ( :mat_khau, :ho_ten, 0, :hinh, :email, 1)";
    $stmt = $conn->prepare($sql);
    $stmt->execute($data);
}
function update($data)
{
    $conn = connect();
    $sql = "UPDATE khach_hang SET mat_khau =:mat_khau, ho_ten =:ho_ten, kich_hoat =:kich_hoat, hinh =:hinh, email =:email, vai_tro =:vai_tro WHERE ma_kh = :ma_kh";
    $stmt = $conn->prepare($sql);
    $stmt->execute($data);
    return true;
}
function update_pass($data)
{
    $conn = connect();
    $sql = "UPDATE khach_hang SET mat_khau = :mat_khau WHERE ma_kh = :ma_kh";
    $stmt = $conn->prepare($sql);
    $stmt->execute($data);
    return true;
}
function update_account($data)
{
    $conn = connect();
    $sql = "UPDATE khach_hang SET ho_ten =:ho_ten, kich_hoat =:kich_hoat, hinh =:hinh, email =:email, vai_tro =:vai_tro WHERE ma_kh = :ma_kh";
    $stmt = $conn->prepare($sql);
    $stmt->execute($data);
    return true;
}
function delete($id)
{
    $conn = connect();
    $sql = "DELETE FROM khach_hang WHERE ma_kh = :ma_kh";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['ma_kh' => $id]);
}
