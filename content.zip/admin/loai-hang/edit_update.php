<?php  
   session_start();
   $id = $_GET['ma_loai'];
   require_once './../db/dbloai-hang.php';
   if(
      empty($_POST['ten_loai'])
  ){
      $_SESSION['error'] = "không bỏ trống thông tin!";
      header("location: /trongtdph17510_ass/SourceFile/admin/loai-hang/update.php?ma_loai=$id?ma_loai=$id");
      die;
  }
   $data = [
    'ma_loai' => $_POST['ma_loai'],
    'ten_loai' => $_POST['ten_loai']
   ];

   update($data);
   header("Location: /trongtdph17510_ass/SourceFile/admin/loai-hang/?btn_list");
