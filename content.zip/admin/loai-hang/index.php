<?php
if (array_key_exists("btn_list", $_REQUEST)) {
    $VIEW_NAME = "admin/loai-hang/list.php";
} else if (array_key_exists("btn_edit", $_REQUEST)) {
    $VIEW_NAME = "admin/loai-hang/edit.php";
} else if (array_key_exists("btn_save", $_REQUEST)) {
    // $MESSAGE = "Thêm hàng hóa thành công!";
    $VIEW_NAME = "admin/loai-hang/edit.php";
} else if (array_key_exists("btn_delete", $_REQUEST)) {
    // $MESSAGE = "Xóa hàng hóa thành công!";
    $VIEW_NAME = "admin/loai-hang/list.php";
} else {
    $VIEW_NAME = "admin/loai-hang/list.php";
}
require './../../layout.php';

