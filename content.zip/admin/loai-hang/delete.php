<?php  
    require_once './../db/dbloai-hang.php';
    $id = $_GET['ma_loai'];
    delete($id);
    header("Location: /trongtdph17510_ass/SourceFile/admin/loai-hang/?btn_list");

?>