<?php  
session_start();
    require_once './../db/dbloai-hang.php';
    $id = $_GET['ma_loai'];
    $data = getid($id);
?>


<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Web design sample project</title>
<!--jQuery-->
<!-- <script src="/trongtdph17510_ass/SourceFile/content/js/jquery.m/in.js"></script> -->
<!--Bootstrap-->
<!-- <script src=""></script> -->
<link href="/trongtdph17510_ass/SourceFile/content/css/bootstrap.min.css" rel="stylesheet"/>
</head>
<body class="container" >
<?php require_once './../../header.php'; ?>
<?php require_once './../db/nav_admin.php'; ?>
    <hr>
    <h2 class="alert alert-danger">QUẢN LÝ LOẠI HÀNG</h2>
    <form action="/trongtdph17510_ass/SourceFile/admin/loai-hang/edit_update.php?ma_loai=<?= $data['ma_loai'] ?>" method="POST">
        <fieldset>
            <div class="mb-3">
                <label for="disabledTextInput" class="form-label">Mã loại</label>
                <input style="background-color: rgba( 0, 0, 0, 0.3);" id="disabledTextInput" name="ma_loai" class="form-control" placeholder="Auto number" value="<?= $data['ma_loai'] ?>">
            </div>
        </fieldset>
        <div class="form-group">
            <label>Tên loại</label>
            <input type="text" name="ten_loai" class="form-control" value="<?= $data['ten_loai'] ?>">
        </div>
        <p style="color:red;">
            <?php if (isset($_SESSION['error'])){
                echo $_SESSION['error'];
                unset($_SESSION['error']);
            }
            ?>
        </p>
        <div class="form-group">
            <button name="btn_save" class="btn btn-primary m-1">Sửa</button>
            <a href="/trongtdph17510_ass/SourceFile/admin/loai-hang?btn_list" class="btn btn-primary m-1">Danh sách</a>
        </div>
    </form>
    <?php require_once './../../footer.php'; ?>
</body>
</html>