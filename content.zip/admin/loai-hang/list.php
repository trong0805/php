<?php
require_once './../db/dbloai-hang.php';
$data = getall();
?>
<!DOCTYPE html>
<html>

<body>
<?php require_once './../db/nav_admin.php'; ?>
    <hr>
    <h2 class="alert alert-danger">QUẢN LÝ LOẠI HÀNG</h2>
    <table class="table" border="1">
        <thead>
            <tr>
                <th>STT</th>
                <th>Mã loại</th>
                <th>Tên loại</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php
            $no = 1;
            foreach ($data as $datas) { ?>
                <tr>
                    <td><?= ($no++) ?></td>
                    <td><?= $datas['ma_loai'] ?></td>
                    <td><?= $datas['ten_loai'] ?></td>
                    <td>
                        <a href="/trongtdph17510_ass/SourceFile/admin/loai-hang/update.php?ma_loai=<?= $datas['ma_loai'] ?>" class="btn btn-primary m-1">Sửa</a>
                        <a href="/trongtdph17510_ass/SourceFile/admin/loai-hang/delete.php?ma_loai=<?= $datas['ma_loai'] ?>" class="btn btn-primary m-1" onclick="confirm('Bạn muốn xóa loại hàng này?');">Xóa</a>
                    </td>
                </tr>
            <?php } ?>

        </tbody>
    </table>
    <a href="/trongtdph17510_ass/SourceFile/admin/loai-hang/?btn_edit" class="btn btn-primary m-1">Thêm mới</a>
</body>

</html>