<?php
    require_once './../db/dbloai-hang.php';
    session_start();
    if(
        empty($_POST['ten_loai'])
    ){
        $_SESSION['error'] = "không bỏ trống thông tin!";
        header("location: /trongtdph17510_ass/SourceFile/admin/loai-hang/?btn_edit");
        die;
    }
    $data = [
        // 'ma_loai' => $_POST['book_page'],
        'ten_loai' => $_POST['ten_loai']
    ];
    
    insert($data);
    header("location: /trongtdph17510_ass/SourceFile/admin/loai-hang/?btn_list");
?>