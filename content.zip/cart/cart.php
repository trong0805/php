<?php

session_start();
if (isset($_POST['thanh_toan'])) {
    if (isset($_SESSION['user'])) {
        if (is_numeric($_POST['phone']) == false) {
            $_SESSION['error'] = "Vui lòng nhập số điện thoại nhận hàng";
        } else {
            $_SESSION['error'] = "Mua hàng thành công!";
            unset($_SESSION['giohang']);
        }
    } else {
        $_SESSION['error'] = "Vui lòng đăng nhập để sử dụng tính năng thanh toán!";
    }
}
if (!isset($_SESSION['giohang'])) $_SESSION['giohang'] = [];
if (empty($_SESSION['giohang']) == true) {
    $_SESSION['checkgiohang'] = "Giỏ hàng trống! Mời bạn mua thêm hàng!";
}
//xóa sp trong giỏ
if (isset($_GET['delgiohang']) && ($_GET['delgiohang'] == 1)) unset($_SESSION['giohang']);
//lấy dữ liệu từ form
if (isset($_POST['addcart']) && ($_POST['addcart'])) {
    $hinh = $_POST['hinh'];
    $ten_hh = $_POST['ten_hh'];
    $don_gia = $_POST['don_gia'];
    $so_luong = $_POST['so_luong'];
    $ma_hh = $_POST['ma_hh'];
    //ktra sp có trong giỏ hàng k 

    $fl = 0; //ktra sp co trùng hay k
    for ($i = 0; $i < sizeof($_SESSION['giohang']); $i++) {
        if ($_SESSION['giohang'][$i][1] == $ten_hh) {
            $fl = 1;
            $soluongnew = $so_luong + $_SESSION['giohang'][$i][3];
            $_SESSION['giohang'][$i][3] = $soluongnew;
            break;
        }
    }
    //neu k trung gio hang thi them moi 
    if ($fl == 0) {

        //them mới vào giỏ hàng
        $prd = [$hinh, $ten_hh, $don_gia, $so_luong, $ma_hh];
        $_SESSION['giohang'][] = $prd;
        // var_dump($_SESSION['giohang']);
    }
}
if (isset($_GET['delid']) && ($_GET['delid'] >= 0)) {
    array_splice($_SESSION['giohang'], $_GET['delid'], 1);
}
function showgiohang()
{
    if (isset($_SESSION['giohang']) && (is_array($_SESSION['giohang']))) {
        $tong = 0;
        for ($i = 0; $i < sizeof($_SESSION['giohang']); $i++) {

            $tt = intval($_SESSION['giohang'][$i][2]) * intval($_SESSION['giohang'][$i][3]);
            $tong += $tt;
            echo '<tr>
            <td>' . ($i + 1) . '</td>
            <td>
                    <img style="width:100px;" src="./../content/img/' . $_SESSION['giohang'][$i][0] . '">
            </td>
            <td>' . $_SESSION['giohang'][$i][1] . '</td>
            <td>' . $_SESSION['giohang'][$i][2] . '</td>
            <td>' . $_SESSION['giohang'][$i][3] . '</td>
            <td>
                <div>' . $tt . '</div>
            </td>
            <td><a href="cart.php?delid=' . $i . '">Xóa</a></td>
        </tr>';
        }
        echo '<tr>
        <th colspan="5">Tổng đơn hàng</th>
        <th>
            <div>' . $tong . '</div>
        </th> 

    </tr>';
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="Description" content="Enter your description here" />
    <title>Title</title>
</head>

<body>
    <!-- <a href="./../home/" >Home</a> -->
    <?php require_once './../header.php'; ?>

    <h2 class="alert alert-danger">Giỏ hàng</h2>
    <table class="table" border="1">
        <thead>
            <tr>
                <th>STT</th>
                <th>Ảnh</th>
                <th>Tên</th>
                <th>Đơn giá</th>
                <th>Số lượng</th>
                <th>Thành tiền</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <p style="color: blue; text-align: center;">
                <?php
                if (isset($_SESSION['checkgiohang'])) {
                    echo $_SESSION['checkgiohang'];
                    unset($_SESSION['checkgiohang']);
                }
                ?>
            </p>
            <?php Showgiohang(); ?>
        </tbody>
    </table>
    <!-- <button type="button" name="" id="" class="btn btn-primary" ></button> -->

    <button type="button" name="" id="" class="mb-1 btn btn-primary"><a class="btn-primary" href="./cart.php?delgiohang=1">Xóa giỏ hàng</a></button>
    <button type="button" name="" id="" class="mb-1 btn btn-primary"><a class="btn-primary" href="./../home?san-pham"> Tiếp tục mua hàng</a></button>
    <h2 class="alert alert-danger">Thanh toán</h2>
    <p style="color: red; text-align: center;">
        <?php
        if (isset($_SESSION['error'])) {
            echo $_SESSION['error'];
            unset($_SESSION['error']);
        }
        ?>
    </p>
    <form action="./cart.php" method="POST">
        <div class="input-group mb-3">
            <span class="input-group-text" id="inputGroup-sizing-default">Tên khách hàng</span>
            <input type="text" class="form-control" name="ten_kh" value="<?php if (empty($_SESSION['user']) == false) {
                                                                                echo $_SESSION['user']['ho_ten'];
                                                                            } else {
                                                                            } ?>" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default">
        </div>
        <div class="input-group mb-3">
            <span class="input-group-text" id="inputGroup-sizing-default">Địa chỉ</span>
            <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default" required>
        </div>
        <div class="input-group mb-3">
            <span class="input-group-text" id="inputGroup-sizing-default">Số điện thoại</span>
            <input type="tel" name="phone" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default" required>
        </div>
        <div class="input-group mb-3">
            <button type="submit" name="thanh_toan" id="" class="mb-1 btn btn-primary">Thanh toán</button>
        </div>
    </form>
    <?php require_once './../footer.php'; ?>

</body>

</html>