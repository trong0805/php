<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>Web design sample project</title>
    <!--jQuery-->
    <!-- <script src="/xshop/SourceFile/content/js/jquery.m/in.js"></script> -->
    <!--Bootstrap-->
    <!-- <script src=""></script> -->
    <link href="/trongtdph17510_ass/SourceFile/content/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta2/css/all.min.css" integrity="sha512-YWzhKL2whUzgiheMoBFwW8CKV4qpHQAEuvilg9FAn5VJUDwKZZxkJNuGM4XkWuk94WCrrwslk8yWNGmY1EduTA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>

<body class="container">
    
    <div class="card" style="text-align: center; background-color: rgba( 0, 0, 0, 0.3);">
        <div class="card-body">
            <h5 class="card-title">Địa chỉ: Cầu Giấy - Hà Nội</h5>
            <p class="card-text">Hotline: 19001001</p>
            <p class="card-text">Gmail: xshop@gmail.com</p>
        </div>

    </div>
</body>

</html>