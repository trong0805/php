<?php
// session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Title</title>
    <!-- <link href="" type="text/css" rel="stylesheet" /> -->
    <style>
        .article {
            width: 70%;
            /* border: 1px solid #ccc; */
        }

        .aside {
            width: 30%;
        }

        .aside-top {
            margin-bottom: 10px;
        }

        .aside-top h4,
        .aside-bottom h4 {
            color: #fff;
            background-color: rgba(0, 0, 0, 0.3);
            text-align: center;
        }

        .aside-bottom {
            /* height: 300px; */
            border: 1px solid #ccc;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="row">
            <div class="article">
                <div class="products">
                    <h2>Tài khoản</h2>
                    <!-- <div class="grid_row"> -->
                    <p style="color: red;">
                        <?php
                        if (isset($_SESSION['acc'])) {
                            echo $_SESSION['acc'];
                            unset($_SESSION['acc']);
                        }
                        ?>
                    </p>
                        <fieldset disabled>
                            <div class="mb-3">
                                <label for="disabledTextInput" class="form-label">Tên</label>
                                <input id="disabledTextInput" class="form-control" value="<?=$_SESSION['user']['ho_ten']?>">
                            </div>
                        </fieldset>
                        <fieldset disabled>
                            <div class="mb-3">
                                <label for="disabledTextInput" class="form-label">Email</label>
                                <input id="disabledTextInput" class="form-control" value="<?=$_SESSION['user']['email']?>">
                            </div>
                        </fieldset>
                        <fieldset disabled>
                            <div class="mb-3">
                                <label for="disabledTextInput" class="form-label">Hình ảnh</label> <br>
                                <img src="./../content/img/<?=$_SESSION['user']['hinh']?>" width="200px">
                            </div>
                        </fieldset>
                        <fieldset disabled>
                            <div class="mb-3">
                                <label for="disabledTextInput" class="form-label">Chức vụ</label>
                                <input id="disabledTextInput" class="form-control" value="<?php
                                if($_SESSION['user']['vai_tro'] == 0){
                                    echo "Admin";
                                } else {
                                    echo "Khách hàng";
                                }
                                
                                ?>">
                            </div>
                        </fieldset>
                </div>
            </div>
            <div class="aside">
                <div class="aside-bottom">
                    <h4>Danh mục</h4>
                    <a href="/trongtdph17510_ass/SourceFile/tai-khoan?btn_upload" class="list-group-item  ">Cập nhật tài khoản</a>
                    <a href="/trongtdph17510_ass/SourceFile/tai-khoan?btn_pass" class="list-group-item  ">Đổi mật khẩu</a>
                    <a href="/trongtdph17510_ass/SourceFile/tai-khoan?btn_account" class="list-group-item  ">Thông tin tài khoản</a>
                </div>
            </div>
        </div>
    </div>
</body>

</html>