<?php
// session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Title</title>
    <!-- <link href="" type="text/css" rel="stylesheet" /> -->
    <style>
        .article {
            width: 70%;
            /* border: 1px solid #ccc; */
        }

        .aside {
            width: 30%;
        }

        .aside-top {
            margin-bottom: 10px;
        }

        .aside-top h4,
        .aside-bottom h4 {
            color: #fff;
            background-color: rgba(0, 0, 0, 0.3);
            text-align: center;
        }

        .aside-bottom {
            /* height: 300px; */
            border: 1px solid #ccc;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="row">
            <div class="article">
                <div class="products">
                    <h2>Đổi mật khẩu</h2>
                    <div class="grid_row">
                        <form method="post" action="/trongtdph17510_ass/SourceFile/tai-khoan/cap-nhat-mk.php?ma_kh=<?= $_SESSION['user']['ma_kh'] ?>" enctype="multipart/form-data">
                            <div class="form-group" hidden>
                                <label>Mã khách hàng</label>
                                <input type="" name="ma_kh" value="<?= $_SESSION['user']['ma_kh'] ?>" class="form-control">
                            </div>
                            <div class="mb-3">
                                <label for="disabledTextInput" class="form-label">Mật khẩu cũ</label> <br>
                                <input id="disabledTextInput" name="old_password" type="password" class="form-control">
                            </div>
                            <div class="mb-3">
                                <label for="disabledTextInput" class="form-label">Mật khẩu mới</label> <br>
                                <input id="disabledTextInput" name="mat_khau" type="password" class="form-control">
                            </div>
                            <p style="color: red;">
                                <?php
                                if (isset($_SESSION['error'])) {
                                    echo $_SESSION['error'];
                                    unset($_SESSION['error']);
                                }
                                ?>
                            </p>
                            <div class="mb-3">
                                <button class="btn btn-primary">Cập nhật</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="aside">
                <div class="aside-bottom">
                    <h4>Danh mục</h4>
                    <a href="/trongtdph17510_ass/SourceFile/tai-khoan?btn_upload" class="list-group-item  ">Cập nhật tài khoản</a>
                    <a href="/trongtdph17510_ass/SourceFile/tai-khoan?btn_pass" class="list-group-item  ">Đổi mật khẩu</a>
                    <a href="/trongtdph17510_ass/SourceFile/tai-khoan?btn_account" class="list-group-item  ">Thông tin tài khoản</a>
                </div>
            </div>
        </div>
    </div>
</body>

</html>