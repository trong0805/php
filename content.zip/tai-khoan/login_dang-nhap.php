<?php
session_start();
require_once './../admin/db/dbkhach-hang.php';

// isset($_POST['email']) == false ||
//     isset($_POST['mat_khau']) == false
if (
    empty($_POST['email'])  ||
    empty($_POST['mat_khau'])
) {
    $_SESSION['error'] = "Không được để trống";

    header("Location: /trongtdph17510_ass/SourceFile/tai-khoan/");
    die;
}

$user = login($_POST['email'], $_POST['mat_khau']);

if (empty($user) == true) {
    $_SESSION['error'] = "Sai tài khoản hoặc mật khẩu";
    header("Location: /trongtdph17510_ass/SourceFile/tai-khoan/");
    die;
}
if($user['kich_hoat'] == 1){
    $_SESSION['error'] = "Tài khoản đã bị vô hiệu hóa";
    header("Location: /trongtdph17510_ass/SourceFile/tai-khoan/");
    die;
}
$_SESSION['user'] = $user;
// header("location: /WE16312/Assignment/admin/san_pham/index.php");
if ($user['vai_tro'] == 0) {
    // echo '<a href="./dang-xuat.php">Đăng xuất</a>';
    header("Location: /trongtdph17510_ass/SourceFile/");
    // echo 'xin chào :'. $_SESSION['user']['ho_ten'];
        // echo '<img src="./../content/img/'.$_SESSION['user']['hinh'].'" />';

}

if ($user['vai_tro'] == 1) {
    // echo ' <a href="./dang-xuat.php">Đăng xuất</a>';
    header("Location: /trongtdph17510_ass/SourceFile/");
    // echo 'xin chào :'. $_SESSION['user']['ho_ten'];
}