<?php
// session_start();
if (
    isset($_SESSION['user']) &&
    empty($_SESSION['user'])
) {
    // người dùng đã đăng nhập -> đẩy về trang quản trị
    header("Location: /trongtdph17510_ass/SourceFile/home/");
}
?>
<!DOCTYPE html>
<html>
<style>
    .main {
        width: 100%;
        background: rgb(238, 174, 202);
        background: radial-gradient(circle, rgba(238, 174, 202, 1) 0%, rgba(186, 144, 186, 1) 42%, rgba(204, 218, 235, 1) 84%);
    }

    .login {
        width: 50%;
        margin: 0 auto;
        padding: 102px 16px 16px;
        min-height: 500px;
        /* background: linear-gradient(to top left, rgba(110, 56, 237, 0.5), green); */
    }

    .login>h2 {
        text-align: center;
    }
</style>

<body>
    <div class="main">
        <div class="login">
            <h2>ĐĂNG NHẬP</h2>

            <form class="form_login" action="/trongtdph17510_ass/SourceFile/tai-khoan/login_dang-nhap.php" method="POST">
                <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Email address</label>
                    <input type="email" name="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                </div>
                <div class="mb-3">
                    <label for="exampleInputPassword1" class="form-label">Password</label>
                    <input type="password" name="mat_khau" class="form-control" id="exampleInputPassword1">
                </div>
                <div class="flex mb-3 form-check">
                    <a href="/trongtdph17510_ass/SourceFile/tai-khoan?btn_resertpass" style="margin-right: 50%;">Quên mật khẩu?</a>
                    <a href="/trongtdph17510_ass/SourceFile/tai-khoan?btn_register">Bạn chưa có tài khoản?</a>
                </div>
                <p style="color: red;">
                    <?php
                    if (isset($_SESSION['error'])) {
                        echo $_SESSION['error'];
                        unset($_SESSION['error']);
                    }
                    ?>
                </p>
                <button type="submit" class="btn btn-primary">Đăng nhập</button>
            </form>
        </div>
    </div>


</body>

</html>