<?php
session_start();
require_once './../admin/db/dbkhach-hang.php';
$id = $_GET['ma_kh'];
$data_img = getid($id);
if (
    empty($_POST['ho_ten'])  ||
    empty($_POST['email'])
) {
    $_SESSION['acc'] = "Không được để trống";
    header("Location: /trongtdph17510_ass/SourceFile/tai-khoan?btn_upload");
    
    die;
}else{
    header("Location: /trongtdph17510_ass/SourceFile/tai-khoan?btn_account");
    $_SESSION['acc'] = "Đổi thông tin khách hàng thành công.Vui lòng đăng nhập lại!";
}
$data = [
    'ma_kh' => $_POST['ma_kh'],
    'ho_ten' => $_POST['ho_ten'],
    'kich_hoat' => $_POST['kich_hoat'],
    'email' => $_POST['email'],
    'hinh' => $_FILES['hinh']['name'],
    'vai_tro' => $_POST['vai_tro']
];
if ($_FILES['hinh']['name'] == '') {
    $data['hinh'] = $data_img['hinh'];
}
if (isset($_FILES['hinh'])) {
    $file = $_FILES['hinh'];
    $file_name = $file['name'];
    move_uploaded_file($file['tmp_name'], './../content/img/' . $file_name);
}

update_account($data);