<?php
session_start();
require_once './../admin/db/dbkhach-hang.php';
if (isset($_SESSION['user']) && $_SESSION['user'] != NULL) {
    unset($_SESSION['user']);
    header("Location: /trongtdph17510_ass/SourceFile/tai-khoan/");
    
}
?>