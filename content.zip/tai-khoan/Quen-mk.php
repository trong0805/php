<!DOCTYPE html>
<html>
<style>
    .main {
        width: 100%;
        background: rgb(238, 174, 202);
        background: radial-gradient(circle, rgba(238, 174, 202, 1) 0%, rgba(186, 144, 186, 1) 42%, rgba(204, 218, 235, 1) 84%);
    }

    .login {
        width: 50%;
        margin: 0 auto;
        padding: 16px;
        min-height: 500px;
    }

    .login>h2 {
        text-align: center;
    }
</style>

<body>
    <div class="main">
        <div class="login">
            <h2>Quên mật khẩu</h2>

            <form class="form_login" method="POST" action="/trongtdph17510_ass/SourceFile/tai-khoan/forget_pass.php">
                <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Email address</label>
                    <input type="email" name="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                </div>
                <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Name account</label>
                    <input type="text" name="ho_ten" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                </div>
                <div class="flex mb-3 form-check">
                    <a href="/trongtdph17510_ass/SourceFile/tai-khoan?btn_register" style="margin-right: 42%;">Bạn chưa có tài khoản?</a>
                    <a href="/trongtdph17510_ass/SourceFile/tai-khoan?btn_login">Bạn đã có tài khoản?</a>
                </div>
                <p style="color: red;">
                    <?php
                    if (isset($_SESSION['error'])) {
                        echo $_SESSION['error'];
                        unset($_SESSION['error']);
                    }
                    ?>
                </p>
                <button type="submit" class="btn btn-primary">Lấy mật khẩu</button>
            </form>
        </div>
    </div>
</body>

</html>