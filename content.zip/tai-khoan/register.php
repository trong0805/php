<?php
session_start();
require_once './../admin/db/dbkhach-hang.php';
$data = getall();
if (
    empty($_POST['mat_khau']) ||
    empty($_POST['ho_ten']) ||
    empty($_FILES['hinh']['name']) ||
    empty($_POST['email'])
) {
    $_SESSION['error'] = "không bỏ trống thông tin!";
    header("Location: /trongtdph17510_ass/SourceFile/tai-khoan?btn_register");
    die;
}
foreach ($data as $dt) {
    if (
       ($_POST['email']) == $dt['email']
    ) {
        $_SESSION['error'] = "Email này đã tồn tại!";
        header("Location: /trongtdph17510_ass/SourceFile/tai-khoan?btn_register");
        die;
    }
 }
$data = [
    'ho_ten' => $_POST['ho_ten'],
    'email' => $_POST['email'],
    'hinh' => $_FILES['hinh']['name'],
    'mat_khau' => $_POST['mat_khau']
];
if (isset($_FILES['hinh'])) {
    $file = $_FILES['hinh'];
    $file_name = $file['name'];
    move_uploaded_file($file['tmp_name'], './../content/img/' . $file_name);
}
insert_register($data);
header("Location: /trongtdph17510_ass/SourceFile/tai-khoan");
