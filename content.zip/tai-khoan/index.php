<?php

if (array_key_exists("btn_register", $_REQUEST)) {
    $VIEW_NAME = "tai-khoan/Dang-ky.php";
} else if (array_key_exists("btn_login", $_REQUEST)) {
    $VIEW_NAME = "tai-khoan/Dang-nhap.php";
} else if (array_key_exists("btn_upload", $_REQUEST)) {
    $VIEW_NAME = "tai-khoan/Cap-nhat-tk.php";
} else if (array_key_exists("btn_resertpass", $_REQUEST)) {
    $VIEW_NAME = "tai-khoan/Quen-mk.php";
} else if (array_key_exists("btn_pass", $_REQUEST)) {
    $VIEW_NAME = "tai-khoan/Doi-mk.php";
} else if (array_key_exists("btn_account", $_REQUEST)) {
    $VIEW_NAME = "tai-khoan/account.php";
} else {
    $VIEW_NAME = "tai-khoan/Dang-nhap.php";
}

require '../layout.php';
?>
