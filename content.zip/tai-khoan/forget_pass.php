<?php
session_start();
require_once './../admin/db/dbkhach-hang.php';
$data = getall();
if (
    empty($_POST['ho_ten']) ||
    empty($_POST['email'])
) {
    $_SESSION['error'] = "không bỏ trống thông tin!";
    header("Location: /trongtdph17510_ass/SourceFile/tai-khoan?btn_resertpass");
    die;
}
foreach ($data as $dt) {
    if(
        ($_POST['email']) == $dt['email'] && ($_POST['ho_ten']) == $dt['ho_ten']
    ){
        $_SESSION['error'] = "Mật khẩu của gmai <span style='color: blue;'>".$dt['email']."</span> là :" .$dt['mat_khau'];
        header("Location: /trongtdph17510_ass/SourceFile/tai-khoan?btn_resertpass");
        die;
    }
    else {
        $_SESSION['error'] = "Tên email hoặc Name Account không chính xác!";
        header("Location: /trongtdph17510_ass/SourceFile/tai-khoan?btn_resertpass");
        
    }
}
