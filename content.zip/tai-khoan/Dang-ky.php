<?php
// session_start();
?>
<!DOCTYPE html name="">
<html>
<style>
    .main {
        width: 100%;
        background: rgb(238, 174, 202);
        background: radial-gradient(circle, rgba(238, 174, 202, 1) 0%, rgba(186, 144, 186, 1) 42%, rgba(204, 218, 235, 1) 84%);
    }

    .login {
        width: 50%;
        margin: 0 auto;
        padding: 56px 16px 16px;
        min-height: 500px;
    }

    .login>h2 {
        text-align: center;
    }
</style>

<body>
    <div class="main">
        <div class="login">
            <h2>ĐĂNG KÝ</h2>

            <form class="form_login" action="/trongtdph17510_ass/SourceFile/tai-khoan/register.php" method="POST" enctype="multipart/form-data">
                <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Email address</label>
                    <input type="email" class="form-control" name="email">
                </div>
                <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Name Full</label>
                    <input type="text" class="form-control" name="ho_ten">
                </div>
                <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Avatar</label>
                    <input type="file" class="form-control" name="hinh">
                </div>
                <div class="mb-3">
                    <label for="exampleInputPassword1" class="form-label">Password</label>
                    <input type="password" class="form-control" name="mat_khau">
                </div>
                <div class="flex mb-3 form-check">
                    <a href="/trongtdph17510_ass/SourceFile/tai-khoan?btn_resertpass" style="margin-right: 50%;">Quên mật khẩu?</a>
                    <a href="/trongtdph17510_ass/SourceFile/tai-khoan?btn_login">Bạn đã có tài khoản?</a>
                </div>
                <p style="color: red;">
                    <?php
                    if (isset($_SESSION['error'])) {
                        echo $_SESSION['error'];
                        unset($_SESSION['error']);
                    }
                    ?>
                </p>
                <button type="submit" class="btn btn-primary">Đăng ký</button>
            </form>
        </div>
    </div>

</body>

</html>