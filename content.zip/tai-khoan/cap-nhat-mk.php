<?php
session_start();
require_once './../admin/db/dbkhach-hang.php';
$_SESSION['error'] = '';
$id = $_GET['ma_kh'];
$pass_cu = getid($id);

$old = [
    'old_password' => $_POST['old_password']
];

if ($old['old_password'] != $pass_cu['mat_khau']) {
    $_SESSION['error'] = 'Mật khẩu cũ không khớp!';
    header("Location: /trongtdph17510_ass/SourceFile/tai-khoan/?btn_pass");
    die;
} else{
    $data = [
        'ma_kh' => $_POST['ma_kh'],
        'mat_khau' => $_POST['mat_khau']
    ];

    update_pass($data);
    header("Location: /trongtdph17510_ass/SourceFile/tai-khoan/?btn_account");
    $_SESSION['acc'] = "Đổi mật khẩu thành công.Vui lòng đăng nhập lại!";
}